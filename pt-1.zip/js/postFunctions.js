// function for uploading post data
function postDataUpload(url, methodType){
   var form_data = new FormData(); //creating form data array
  var file_data = $("#featureImage").prop("files")[0];//handling image

  var user_id = $('meta[name="user_id"]').attr('content');//handling user_id
  var post_description = tinymce.activeEditor.getContent();//handling test editor
  //handling categories array
  var categories = $("#category_id").val();
  var category_id =[];
  if(categories !=""){

  for(var i = 0 ; i < categories.length ; i++){
    var obj = {"id": categories[i]};
    category_id.push(obj);
  }; // creating object for sending the category array
  var category_id = JSON.stringify(category_id); //getting array ready.
  console.log(category_id);
  form_data.append("category_id", category_id); // adding the category_id to form_data
  }
   //handling form data to be send

  form_data.append("featureImage", file_data);
  form_data.append("post_description", post_description);
  form_data.append("post_title", $("#post_title").val());
  form_data.append("post_summary", $("#post_summary").val());
  form_data.append("post_keywords", $("#post_keywords").val());
  form_data.append("post_status", post_status);
  form_data.append("user_id", user_id);
  form_data.append("post_id", post_id);
  if(methodType === 'put'){
    form_data.append("_method", 'put');
  }




  // ajax for sending  form_data
  $.ajax({
      url: url,
      //dataType: 'script',
      cache: false,
      contentType: false,
      processData: false,
      data: form_data,
      type: 'post',
      headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
     },
      success: function(data){
        console.log(data['post_id']);
         $('#errorSection').empty();
        var alertTop ='<div class="alert alert-danger alert-dismissible fade show" role="alert">';
        var successalertTop ='<div class="alert alert-success alert-dismissible fade show" role="alert">';
        var alertButtom = '<button type="button" class="close" data-dismiss="alert" aria-label="Close">'
        +'<span aria-hidden="true">&times;</span>'
        +'</button>'
        +'</div>';

        if(data['post_id']){
          var post_idX = data['post_id'];
          var urlX ='/postAttribute/';
          var methodX="";
          if(post_id === 0){
          methodX ="post";
          }
          else{
          methodX ="put";
          }
          //saving attributes
          var att = $('.attributes');
          console.log(att);
          $.each(att,function(key, value) {

              var attNamex = $(value).attr('attNamex');
              var postAttID = $(value).attr('postAttID');
              //console.log(attNamex);
           var formdata ={
             'attribute_value':value.value,
             'attribute_id':value.id,
             'attribute_name':attNamex,
             'post_id':post_idX,
           };
           console.log("55555555555555555555");
           console.log(formdata);
           if(methodX==="put"){
             urlX ='/postAttribute/'+postAttID;

           }

            $.ajax({
                url: urlX,
                //dataType: 'script',
                cache: false,
                /*contentType: false,*/
                /*processData: false,*/
                data: formdata,
                type: methodX,
                headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
               success: function(data){
                 console.log(data);
                if(methodX==="post"){
                 value.postAttID = data ;
                  }
                 console.log(value);
               }


              });
          });






          if(post_id ===0){
          var alert =successalertTop+'Saved successfully'+alertButtom;
          $('#errorSection').append(alert);

          }
          else{
            var alert =successalertTop+'Updated successfully'+alertButtom;
            $('#errorSection').append(alert);
          }
          if(post_status === 0){
            $('#publishOrDraft').empty();
          $("#publishOrDraft").html('Publish');
          }

          if(post_status === 1){
            $('#publishOrDraft').empty();
          $("#publishOrDraft").html('Draft');
          }
           post_id = data['post_id'];
          setTimeout(function(){ $('#errorSection').empty(); }, 10000);
        }
        if(data['post_title']){
          var alert =alertTop+data['post_title']+alertButtom;
          $('#errorSection').append(alert);

        }

        if(data['post_description']){
          var alert =alertTop+data['post_description']+alertButtom;
          $('#errorSection').append(alert);
        }

        if(data['featureImage']){
          var alert =alertTop+data['featureImage']+alertButtom;
          $('#errorSection').append(alert);
        }

        if(data['category_id']){
          var alert =alertTop+'The category field is required.'+alertButtom;
          $('#errorSection').append(alert);
        }


      }
  });
}
/******************************************/
/*               Delete Function         */
/*****************************************/
function deletePost(url){
  $.ajax({
      url: url,
      //dataType: 'script',
      cache: false,
      /*contentType: false,
      processData: false,*/
      data: {'_method' : "Delete"},
      type: 'post',
      headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
     },
      success: function(data){
        window.location.replace("/admin/post");
      }
      });

}

/******************************************/
/*            getting attributes         */
/*****************************************/

function getAttributes(url){
  $.ajax({
      url: url,
      //dataType: 'script',
      cache: false,
      /*contentType: false,
      processData: false,*/
      //data: {'_method' : "Delete"},
      type: 'get',
      headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
     },
      success: function(data){
        console.log(data);
      //  $('#attributes').append('sdasd');
      $.each( data, function( key, value ) {
       //alert( key + ": " + value );
       //alert(value.type);
       if(value.type === 'input'){
        var formItem =
        '<div class="form-group row">'
        +  '<label class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-2 col-form-label" for="post_title">'+value.name+'</label>'
        +'<div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">'
        + '<input maxlength="250" spellcheck="true" type="text" class="form-control attributes" attNamex="'+value.name+'" postAttID="" id="'+value.id+'" name="'+value.id+'">'
        + ' </div>'
          +'<br>'
       + '</div>';
       $('#attributes').append(formItem);
       }
       if(value.type === 'option'){
         //var options = '<option>'+value.options[0].name+'</option>';
         var options = "";
         $.each(value.options, function( key, value ) {
          options += '<option value="'+value.name+'">'+value.name+'</option>'
         });

         var formItem =
         '<div class="form-group row">'
         +  '<label class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-2 col-form-label" for="post_title">'+value.name+'</label>'
         +'<div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">'
        + '<select  class="form-control attributes" attNamex="'+value.name+'" postAttID="" name="'+value.id+'" id="'+value.id+'">'
        +options
        +  ' </select>'
         + ' </div>'
           +'<br>'
        + '</div>';
        $('#attributes').append(formItem);
       }
 });

      }
      });
}

/******************************************/
/*            convert text to html        */
/*****************************************/

function decodeHTMLEntities(text) {
 var entities = [
     ['amp', '&'],
     ['apos', '\''],
     ['#x27', '\''],
     ['#x2F', '/'],
     ['#39', '\''],
     ['#47', '/'],
     ['lt', '<'],
     ['gt', '>'],
     ['nbsp', ' '],
     ['quot', '"']
 ];

 for (var i = 0, max = entities.length; i < max; ++i)
     text = text.replace(new RegExp('&'+entities[i][0]+';', 'g'), entities[i][1]);

 return text;
}
