
// for picture preview.

function readUrl(input){

if(input.files && input.files[0]){
  var reader = new FileReader();
  reader.onload = function(e){
  $('#preview').attr('src', e.target.result);
}
  reader.readAsDataURL(input.files[0]);
}

}

// add rules image input and show the uploaded image before sent and enabling the upload button.
$('#featureImage').change(function() {
  var image = $('#featureImage').val();
  var extension = image.split('.').pop().toUpperCase();
  var file_size = $('#featureImage')[0].files[0].size;

  if (extension!="PNG" && extension!="JPG" && extension!="GIF" && extension!="JPEG"){
      alert("invalid extension "+extension);
  }
  if(file_size>1000000){

  alert("File size is greater than 1MB ");
  $('#title').val() = "";
}
else {


	if ($('#title').val() != ""){
    $('#submit').removeAttr('disabled');
      readUrl(this);

    }
else{
      readUrl(this);
    }
}
});
/********************/

$(document).ready(function() {
//getting categories

getcates();
if(post_status===1){
  $('#publishOrDraft').empty();
$("#publishOrDraft").html('Draft');
}

//tinymce setting
  tinymce.init({

    selector:'#post_description',
    theme: 'modern',
    branding: false,
    mobile: { theme: 'mobile' },
     plugins: "textcolor colorpicker code directionality emoticons link wordcount preview searchreplace ",
     toolbar: "code forecolor backcolor bold italic underline alignleft aligncenter alignright alignjustify ltr rtl emoticons link preview searchreplace ",
     browser_spellcheck : true,

   });
//convert text to html
 postContect = decodeHTMLEntities(postContect);
tinymce.activeEditor.execCommand('mceInsertContent', false, postContect);
  //add width to the feature image preview div
  var feaWidth = $('#featureImage').width();
  $('.thefeaturImgPre').css('width',feaWidth);

//dropzone
//ajax for loading attributes
//getAttributes('/postAttribute');

});
//closing the table
$('#close').on("click", function(e) {
e.preventDefault();

});

$('#delete').on("click", function(e) {
  e.preventDefault();
  var delOkay = confirm("Do you want to delete this post?");
  if(delOkay){
    var url = '/post/'+post_id;
  deletePost(url);
  }
});
//saving post data ajax

$("#save").on("click", function(e) {
  e.preventDefault();
  if(post_id===0){
  postDataUpload('/post','post');
  }
  else{
  postDataUpload('/post/'+post_id,'put');
  }
});
//publishOrDraft post data ajax
  $("#publishOrDraft").on("click", function(e) {
    e.preventDefault();
    var Mrbreak = false;
    if(post_id===0){
    post_status = 1;
    postDataUpload('/post','post');
    }
    else{

    if(post_status === 0 ){
    post_status = 1;
    Mrbreak = true;
    }

    if((post_status === 1) && (Mrbreak == false)){
    post_status = 0;
    }
    postDataUpload('/post/'+post_id,'put');
    alert(post_status);
    }

});
/***********************************/
/*      getting categories         */
/***********************************/
//has a child
function hasChild(parent, array){
var childern = [];

$.each(array, function(key, value) {
if(parent.id == value.parent_id){
childern.push(value);
//alert(parent.id+'--------'+key.parent_id+'--'+childern[0].id);
}
});

if(childern.length >= 0){
return true;

}
else{
return false;

}

}//hasChild

/******************************/

//build menu

function buildMenu(root,array,x){
var dash = x;

dash +="- " ;
categories.push(root);
//alert(hasChild(root,array));
//var man =hasChild(root,array);

if(hasChild(root,array)){


$.each(array, function(key, value) {

if(value.parent_id == root.id ){

value.name =dash+value.name;

buildMenu(value,array,dash);

}

});

}


}

/****************************************/

function getcates(){
  var table=[];
  var roots =[];
  var counter = "- ";

  $.get("/category", function(data){

   table = data ;
 console.log(table);
   $.each(table, function(key, value) {
   if(value.parent_id == null){
   roots.push(value);
   console.log(roots);
   }//if
 });//each


 $.each(roots, function(key, value) {
 buildMenu(value,table,"");
 });
console.log(categories);
gettingOptions(categories,'#category_id');
});//get

}//getcates
/******************************/
function gettingOptions(array,element){
  var options ="";
  var selectX="";
  var Mrurl = "/admin/post/getcates/"+post_id;
  $.get(Mrurl, function(dataX){
    $.each(array,function(key, value) {
     $.each(dataX,function(keyD, valueD) {

      if(value.id == valueD.id){
       selectX ="selected";
      }

    });//dataX
     options +='<option '+selectX+' value="'+value.id+'">'+value.name+'</option>';

      selectX ="";

  });//array
$(element).append(options);
  });

//return options;

}


/*
$scope.getcates = function(){
$http.get("/category")
.then(function(response) {
$scope.table = response.data;
$scope.roots =[];

angular.forEach(response.data, function(value, key) {
if(value.parent_id == null){
$scope.roots.push(value);
}
});

//getChildern
$scope.categories = [];

//has a child
$scope.hasChild = function (parent, array){
var childern = [];

$( array ).each(function() {
if(parent.id == this.parent_id){
childern.push(this);
}
});

if(childern.length >= 0){
return true;
}
else{
return false;
}
};
//build menu

$scope.buildMenu = function(root,array,x){
var dash = x;

dash +="- " ;
$scope.categories.push(root);

if($scope.hasChild(root,array)){

$(array).each(function(){

if(this.parent_id == root.id ){

this.name =dash+this.name;

$scope.buildMenu(this,array,dash);

}

});

}


}
$scope.counter = "- ";
angular.forEach($scope.roots, function(value, key) {
$scope.buildMenu(value,$scope.table,"");
});

});
}
$scope.getcates();
*/
