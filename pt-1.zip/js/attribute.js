
// attribute table.
var app = angular.module('caTable', []);
app.controller('tableCTRL', function($scope, $http) {


//getting attributes

$scope.getAttrs = function(){
   $http.get("/attribute")
    .then(function(response) {

      $scope.attributes = response.data;

    });
    }
$scope.getAttrs();
//handling adding new attribute
$scope.attribute_type = 'input';
$scope.addEditAttribute=function(url,methodType){

  if(methodType == 'post'){
$http({
        method : "POST",
        data:{
        '_TOKEN': $('meta[name="csrf-token"]').attr('content'),
        'user_id':$('meta[name="user_id"]').attr('content'),
        'attribute_name':$scope.attribute_name,
        'attribute_type':$scope.attribute_type,
        'attribute_description':$scope.attribute_description,

         },
        url : url
    }).then(function mySuccess(response) {


        alert(response.data.name+" Added Successfuly");
        console.log(response.data);
       $scope.getAttrs();
       if($scope.attribute_type =='option'){
         $('#add_attribute, #addAttrTitle').hide();
        $scope.attribute_id = response.data.id;
        $('#addingOptions').removeClass('d-none');
       }


    }, function myError(response) {
        console.log(response.data);
    });
   }

   //for  put method to edit ;
     if(methodType == 'put'){
       $http({
               method : "POST",
               data:{
               '_method':'put',
               '_TOKEN': $('meta[name="csrf-token"]').attr('content'),
               'user_id':$('meta[name="user_id"]').attr('content'),
               'attribute_name':$scope.attribute_name,
               'attribute_type':$scope.attribute_type,
               'attribute_description':$scope.attribute_description,

                },
               url : url
           }).then(function mySuccess(response) {

               if(response.data == 200){
                 alert('Successfuly edited');
               }
               else{
                 alert(response.data);
               }


               console.log(response.data);
               $scope.getAttrs();
           }, function myError(response) {
             alert('Error');
               console.log(response.data);
           });
     }


}
$scope.addAttributeSubmit = function(){
  $scope.addEditAttribute('/attribute','post')
}
$scope.editAttributeSubmit  = function(){
  var url = "/attribute/"+$scope.idToedit;
$scope.addEditAttribute(url ,'put');
};
//handling Options
$scope.addOption = function(){
  $http({
          method : "POST",
          data:{
          '_TOKEN': $('meta[name="csrf-token"]').attr('content'),
          'user_id':$('meta[name="user_id"]').attr('content'),
          'option_name':$scope.option_name,
          'attribute_id':$scope.attribute_id,
          'attribute_description':$scope.attribute_description,

           },
          url : '/option'
      }).then(function mySuccess(response) {


          alert("Added Successfuly");

          $http.get("/attribute/"+$scope.attribute_id)
           .then(function(response) {

             $scope.theAttribute = response.data;

           });


      }, function myError(response) {
          console.log(response.data);
      });
     }

//editing attributes
$scope.mr_edit = function(x){
var ediOkay = confirm("Do you want to edit '"+x.name+"' category?");
if(ediOkay){


$scope.attribute_name =  x.name;
$scope.idToedit=x.id;
$scope.attribute_type =x.type;
$scope.attribute_description =x.description;
$scope.parentCategory = {'id' : x.parent_id};
//hide add form items
angular.element( document.querySelector( '#addAttr' ) ).addClass('d-none');
angular.element( document.querySelector( '#addAttrTitle' ) ).addClass('d-none');
//show edit form items
angular.element( document.querySelector( '#editAttrTitle' ) ).removeClass('d-none');
angular.element( document.querySelector( '#editAttr' ) ).removeClass('d-none');
angular.element( document.querySelector( '#switchForm' ) ).removeClass('d-none');
angular.element( document.querySelector( '#addingOptions' ) ).addClass('d-none');
$('#add_attribute, #addAttrTitle').show();
}
}
//editing options

$scope.mr_editOption = function(x){
  $('#add_attribute, #addAttrTitle').hide();
  $scope.attribute_name =  x.name;
  $scope.attribute_id =x.id;
  $http.get("/attribute/"+x.id)
   .then(function(response) {

     $scope.theAttribute = response.data;

   });

angular.element( document.querySelector( '#addingOptions' ) ).removeClass('d-none');
}
//handling switch from to adding
$scope.switchForm = function(){
$scope.attribute_name ="";
$scope.attribute_description ="";
$scope.attribute_type ="input";

  //show add form items
  angular.element( document.querySelector( '#addAttr' ) ).removeClass('d-none');
  angular.element( document.querySelector( '#addAttrTitle' ) ).removeClass('d-none');
  //hide edit form items
  angular.element( document.querySelector( '#editAttrTitle' ) ).addClass('d-none');
  angular.element( document.querySelector( '#editAttr' ) ).addClass('d-none');
  angular.element( document.querySelector( '#switchForm' ) ).addClass('d-none');
}
//deleting Options

$scope.mrdelOption= function(x){
  var delOkay = confirm("Do you want to delete '"+x.name+"'?");
  if(delOkay){
    //var url =
    $http({
            method : "POST",

            data:{
            '_TOKEN': $('meta[name="csrf-token"]').attr('content'),
             '_method' : "Delete"
             },
            url : "/option/"+x.id,

        }).then(function mySuccess(response) {

          if(response.data == 200){
            alert('Successfuly deleted');
            $http.get("/attribute/"+x.attribute_id)
             .then(function(response) {

               $scope.theAttribute = response.data;

             });
          }
            //console.log(response.data);
            $scope.getAttrs();
        }, function myError(response) {
            //alert(response.data);
        });
  }
}
//deleting attributes
$scope.mr_delete = function(x){
  var delOkay = confirm("Do you want to delete '"+x.name+"'?");
  if(delOkay){
    //var url =
    $http({
            method : "POST",

            data:{
            '_TOKEN': $('meta[name="csrf-token"]').attr('content'),
             '_method' : "Delete"
             },
            url : "/attribute/"+x.id,

        }).then(function mySuccess(response) {
          if(response.data == 200){
            alert('Successfuly deleted');
          }
            //console.log(response.data);
            $scope.getAttrs();
        }, function myError(response) {
            //alert(response.data);
        });
  }
}

});
