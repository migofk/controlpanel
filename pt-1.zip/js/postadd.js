var post_status = 0;
var post_id = 0;
// for picture preview.

function readUrl(input){

if(input.files && input.files[0]){
  var reader = new FileReader();
  reader.onload = function(e){
  $('#preview').attr('src', e.target.result);
}
  reader.readAsDataURL(input.files[0]);
}

}

// add rules image input and show the uploaded image before sent and enabling the upload button.
$('#featureImage').change(function() {
  var image = $('#featureImage').val();
  var extension = image.split('.').pop().toUpperCase();
  var file_size = $('#featureImage')[0].files[0].size;

  if (extension!="PNG" && extension!="JPG" && extension!="GIF" && extension!="JPEG"){
      alert("invalid extension "+extension);
  }
  if(file_size>1000000){

  alert("File size is greater than 1MB ");
  $('#title').val() = "";
}
else {


	if ($('#title').val() != ""){
    $('#submit').removeAttr('disabled');
      readUrl(this);

    }
else{
      readUrl(this);
    }
}
});
/********************/

$(document).ready(function() {


//tinymce setting
  tinymce.init({

    selector:'#post_description',
    theme: 'modern',
    branding: false,
    mobile: { theme: 'mobile' },
     plugins: "textcolor colorpicker code directionality emoticons link wordcount preview searchreplace ",
     toolbar: "code forecolor backcolor bold italic underline alignleft aligncenter alignright alignjustify ltr rtl emoticons link preview searchreplace ",
     browser_spellcheck : true,

   });

  //add width to the feature image preview div
  var feaWidth = $('#featureImage').width();
  $('.thefeaturImgPre').css('width',feaWidth);

//dropzone
//ajax for loading attributes
getAttributes('/postAttribute');

});
//closing the table
$('#close').on("click", function() {


});

$('#delete').on("click", function() {
  var delOkay = confirm("Do you want to delete this post?");
  if(delOkay){
    var url = '/post/'+post_id;
  deletePost(url);
  }
});
//saving post data ajax

$("#save").on("click", function() {
  if(post_id===0){
  postDataUpload('/post','post');
  }
  else{
  postDataUpload('/post/'+post_id,'put');
  }
});
//publishOrDraft post data ajax
  $("#publishOrDraft").on("click", function() {
    var Mrbreak = false;
    if(post_id===0){
    post_status = 1;
    postDataUpload('/post','post');
    }
    else{

    if(post_status === 0 ){
    post_status = 1;
    Mrbreak = true;
    }

    if((post_status === 1) && (Mrbreak == false)){
    post_status = 0;
    }
    postDataUpload('/post/'+post_id,'put');
    alert(post_status);
    }

});
/***********************************/
var appPost = angular.module('addPost', []);


appPost.controller('addPostCTRL',  ['$scope',  '$http',function ($scope,  $http) {
//ajax for getting categories
$scope.getcates = function(){
$http.get("/category")
.then(function(response) {
$scope.table = response.data;
$scope.roots =[];

angular.forEach(response.data, function(value, key) {
if(value.parent_id == null){
$scope.roots.push(value);
}
});

//getChildern
$scope.categories = [];

//has a child
$scope.hasChild = function (parent, array){
var childern = [];

$( array ).each(function() {
if(parent.id == this.parent_id){
childern.push(this);
}
});

if(childern.length >= 0){
return true;
}
else{
return false;
}
};
//build menu

$scope.buildMenu = function(root,array,x){
var dash = x;

dash +="- " ;
$scope.categories.push(root);

if($scope.hasChild(root,array)){

$(array).each(function(){

if(this.parent_id == root.id ){

this.name =dash+this.name;

$scope.buildMenu(this,array,dash);

}

});

}


}
$scope.counter = "- ";
angular.forEach($scope.roots, function(value, key) {
$scope.buildMenu(value,$scope.table,"");
});

});
}
$scope.getcates();
/****************************/
//creating directive for files upload

/****************************************/

// send data ajax function




}]);
